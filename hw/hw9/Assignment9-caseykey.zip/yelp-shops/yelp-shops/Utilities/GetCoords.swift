//
//  GetLocation.swift
//  yelp-shops
//
//  Created by Key, Casey on 11/27/22.
//

import Foundation
import CoreLocation
import Alamofire
import SwiftyJSON
import PromiseKit

enum PromiseErrors: Error {
    case geocodeError
}

struct LocationModel {
    public var longitude: String?
    public var latitude: String?
}

func getCoords(from address: String?, ifnot autodetect: Bool) async -> LocationModel? {
    await withCheckedContinuation { continuation in
        getCoords(from: address, ifnot: autodetect) { location in
            continuation.resume(returning: location)
        }
    }
}

func getCoords(from address: String?, ifnot autodetect: Bool, completion: @escaping (LocationModel?) -> ()) {
    
    if (autodetect) {
        let autodetectLocationService = AutodetectLocationService()
        autodetectLocationService.getCoords() { location in
            if (location != nil) {
                completion(location!)
            } else {
                print("Error: Could not autodetect location")
            }
        }
    } else {
        // TODO: use if-let and figure out completion for failure (api broken)
        let geocodingRequest = GeocodingRequest(address: address!)
        let geocodingService = GeocodingService(geocodingRequest)
        geocodingService.getCoords() { location in
            if (location != nil) {
                completion(location!)
            } else {
                print("Error: Could not geocode address")
            }
        }
    }
    
}

class AutodetectLocationService {
    let baseUrl = "https://ipinfo.io/json"
    
    func getCoords(completion: @escaping (LocationModel?) -> ()) {
        let params = ["token": "7c62390b3fc18d"]
    
        AF.request("https://ipinfo.io/json", parameters: params).responseJSON { (response) in
            switch response.result {
            case let .success(value):
                let swiftyJson = JSON(value)
                var coords = swiftyJson["loc"].stringValue.components(separatedBy: ",")
                let location = LocationModel(longitude: coords[1], latitude: coords[0])
               completion(location)
            case let .failure(error):
                debugPrint(error)
            }
        }
    }
}

// The following is adapted from this tutorial:
// https://medium.com/aeturnuminc/geocoding-in-swift-611bda45efe1

class GeocodingRequest {
    
    var address: String
    
    init(address: String) {
        self.address = address
    }
    
    func toParameters() -> Parameters {
        
        let parameters: Parameters = [
            "address": self.address,
            "key": "AIzaSyD8rjrmgl4gDqIOcN-cFfTnL-TYlYkKjOY"
        ]
        
        return parameters
    }
    
}

class GeocodingService {
    
    var geocodingUrl = URLGenerator.geocodingApiUrl(path: "json")
    var geocodingRequest: GeocodingRequest
    
    init(_ geocodingRequest: GeocodingRequest) {
        self.geocodingRequest = geocodingRequest
    }
    
    func getCoords(completion: @escaping (LocationModel?) -> ()) {
        
        let parameters = geocodingRequest.toParameters()

        AF.request(geocodingUrl, method: .get, parameters: parameters, encoding: URLEncoding.default).responseJSON {
            response in
            
            switch response.result {
            case .success(let json):
                
                var geocoding: Geocoding? = nil
                if let geocodingManagerDictionary = json as? NSDictionary {
                    let geocodingManager = GeocodingManager(geocodingDictionary: geocodingManagerDictionary)
                    geocoding = geocodingManager.serialize()
                }
                
                if geocoding != nil {
                    let coords: CLLocationCoordinate2D = geocoding!.coordinates
                    let location = LocationModel(longitude: String(coords.longitude), latitude: String(coords.latitude))
                    completion(location)
                } else {
                    print(PromiseErrors.geocodeError)
                }
                
            case .failure(let error):
                print(error)
            }
        }
        
    }
    
}

class GeocodingManager {
    
    var geocoding: Geocoding? = nil
    var geocodingDictionary: NSDictionary
    
    required init(geocodingDictionary: NSDictionary) {
        self.geocodingDictionary = geocodingDictionary
    }
    
    func serialize() -> Geocoding? {
        
        if self.geocodingDictionary["status"] as! String == "REQUEST_DENIED" {
            debugPrint("ERROR: geocoding failed", self.geocodingDictionary)
            return nil
        }
        
        if let resultArray = self.geocodingDictionary["results"] as? NSArray {
            if let resultDictionary = resultArray[0] as? [String:AnyObject] {
                
                //coordinates
                var coordinates = CLLocationCoordinate2D()
                if let value = resultDictionary["geometry"] as? NSDictionary {
                    if let location = value["location"] as? [String:AnyObject] {
                        let latitude = CLLocationDegrees(location["lat"]?.floatValue ?? 0.0)
                        let longitude = CLLocationDegrees(location["lng"]?.floatValue ?? 0.0)
                        coordinates.latitude = latitude
                        coordinates.longitude = CLLocationDegrees(longitude)
                    }
                }
                
                if coordinates.latitude != 0.0 {
                    let geocoding = Geocoding(coordinates: coordinates)
                    return geocoding
                } else {
                    return nil
                }
            }
        }
        return nil
    }
}
