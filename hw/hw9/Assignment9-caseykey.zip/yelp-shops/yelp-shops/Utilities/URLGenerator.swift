//
//  URLGenerator.swift
//  yelp-shops
//
//  Created by Key, Casey on 11/23/22.
//

import Foundation

class URLGenerator {
    
    static let geocodingbaseUrl: String = "https://maps.googleapis.com/maps/api/geocode"

    class func geocodingApiUrl(path: String) -> String {
        
        return URLGenerator.geocodingbaseUrl + "/" + path
        
    }
    
}
