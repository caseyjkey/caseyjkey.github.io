//
//  ContentView.swift
//  yelp-shops2
//
//  Created by Key, Casey on 11/17/22.
//

import SwiftUI
import CoreLocation
import Alamofire
import SwiftyJSON
import PromiseKit
import Combine

struct ContentView: View {
    @State private var search: String = ""
    @State private var showSearchPopover = false
    @State private var popoverTapped = false
    @FocusState private var searchFocus: Bool
    
    @State private var distance: String = "10"
    
    @State private var categoryIndex = 0
    @State private var selectedCategory = "all"
    let categories = ["Default", "Arts & Entertainment", "Health & Medical", "Hotels & Travel", "Food", "Professional Services"]
    let apiCategories = ["all", "arts", "health", "hotelstravel", "food", "professional"]
    
    @State private var location = ""
    @State private var autodetect = false
    
    @State private var shops: [Business] = [Business]()
    
    @ObservedObject var observed = Observer()
    @ObservedObject var observedSearch = ShopObserver()
    
    struct SearchData : Identifiable{
        public var id: Int
        public var result: String
    }
    
    class Observer : ObservableObject{
        @Published var results = [SearchData]()
        @Published var loading = false
        init() {
        }
        
        func getResults(search: String) {
            self.results = [SearchData]()
            var texts: [String] = []
            let params = ["term": search]
            self.loading = true
            AF.request("https://api-dot-next-yelp-shops.wl.r.appspot.com/autocomplete", parameters: params).responseJSON { (response) in
                self.loading = false
                switch response.result {
                case let .success(value):
                    let swiftyJson = JSON(value)
                    for (key, value) in swiftyJson {
                        if (key == "categories" && !value.isEmpty) {
                            for category in value {
                                texts.append(category.1["title"].rawValue as! String)
                            }
                        } else if (key == "terms") {
                            for term in value {
                                texts.append(term.1["text"].rawValue as! String)
                            }
                        }
                    }
                    for i in 0..<texts.count {
                        self.results.append(SearchData(id: i, result: texts[i]))
                    }
                    /*
                    if (self.results.count == 0) {
                        self.results = [nil]
                    }*/
                    debugPrint("done", search, self.results.count)
                case let .failure(error):
                    debugPrint(error)
                }
                
            }
        }
    }
    
    struct ShopData : Decodable {
        public var location: String
        public var categories: String
        public var display_phone: String
        public var price: String
        public var hours: String
        public var url: String
    }
    

    
    class ShopObserver : ObservableObject{
        @Published public var results = [ShopData]()
        @Published public var loading = false
        @Published public var loaded = false
        
        func getShops(search: String, distance: String, category: String, location: String?=nil, autodetect: Bool) async -> ([Business]?) {
            var shops: Businesses
            let coords = await getCoords(from: location, ifnot: autodetect)
            let params = [
                "term": search,
                "radius": String(Int(distance)! * 1609),
                "latitude": coords?.latitude!,
                "longitude": coords?.longitude!,
                "categories": category
            ]
            debugPrint("getShops", params)
            
            self.loading = true
            do {
                shops = try await AF.request("https://api-dot-next-yelp-shops.wl.r.appspot.com/search", parameters: params).serializingDecodable(Businesses.self).value
                self.loading = false
                self.loaded = true

                return shops.businesses
            } catch {
                self.loading = false
                print("Error searching for shops:", error)
                self.loaded = true
                return nil
            }
        }
    }
    
    
    func setSearch(selected: String) {
        self.search = selected
    }
    
    func dismissPopover(tapped: Bool = false) {
        self.showSearchPopover = false
        self.popoverTapped = true
    }
    
    @State private var searchTask: DispatchWorkItem?
    
    @State var disabledSubmit: Bool = true
    
    var body: some View {
        NavigationStack {
            List {
                HStack {
                    Text("Keyword:")
                        .foregroundColor(Color.gray)
                    TextField("Required", text: $search)
                        .onChange(of: search, perform: { newTag in
                            if (!popoverTapped && newTag.count > 0) {
                                searchTask?.cancel()
                                let task = DispatchWorkItem {
                                    addAutocompleteResults()
                                    showSearchPopover = true
                                }
                                searchTask = task
                                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 0.75, execute: task)
                            } else {
                                popoverTapped = false
                            }
                            if (search.count == 0) {
                                showSearchPopover = false
                            }
                            
                            debugPrint("test", newTag, $showSearchPopover, popoverTapped)
                        })
                        .alwaysPopover(isPresented: $showSearchPopover) {
                            if (observed.loading && observed.results.count == 0) {
                                VStack {
                                    ProgressView()
                                        .frame(maxWidth: .infinity)
                                        .padding(.bottom, -15.0)
                                    Text("loading...")
                                        .font(.subheadline)
                                        .foregroundColor(.gray)
                                        .padding()
                                }
                                .padding(.top, 16.0)
                            } else if (observed.results.count > 0) {
                                VStack {
                                    ForEach(observed.results, id: \.id) { searchData in
                                        let _ = debugPrint("searchData", searchData.id)
                                        Text(searchData.result)
                                            .foregroundColor(.gray)
                                            .onTapGesture() {
                                                self.setSearch(selected: searchData.result)
                                                dismissPopover(tapped: true)
                                            }
                                    }
                                }
                                .padding()
                            }
                        }
                    
                    
                }
                HStack {
                    Text("Distance:")
                        .foregroundColor(Color.gray)
                    TextField("Required", text: $distance).focused($searchFocus)
                        .keyboardType(.numberPad)
                        .onReceive(Just(distance)) { newValue in
                            let filtered = newValue.filter { "0123456789".contains($0) }
                            if filtered != newValue {
                                self.distance = filtered
                            }
                        }
                }
                HStack {
                    Text("Category:")
                        .foregroundColor(Color.gray)
                    Menu {
                        ForEach(Array(categories.enumerated()), id: \.offset){index, category in
                            Button(action: {
                                self.categoryIndex = index
                                self.selectedCategory = category
                            }, label: {
                                Text(category)
                                if selectedCategory == categories[index] {
                                    Image(systemName: "checkmark")
                                }
                                
                            })
                        }
                    } label: {
                        Text(categories[categoryIndex])
                            .foregroundColor(.blue)
                        
                    }
                }
                if (!autodetect) {
                    HStack {
                        Text("Location:")
                            .foregroundColor(Color.gray)
                        TextField("Required", text: $location)
                    }
                }
                HStack {
                    Text("Auto-detect my location:")
                        .foregroundColor(Color.gray)
                        .frame(width: 189)
                    Toggle("", isOn: $autodetect)
                }
                HStack {
                    Button(action: { async {
                        shops = await observedSearch.getShops(search: search, distance: distance, category: selectedCategory, location: location, autodetect: autodetect) ?? [Business]()
                        print("retrieved:", shops as Any)
                    }}) {
                        Text("Submit")
                            .frame(minWidth: 0, maxWidth: 80)
                            .font(.system(size: 18))
                            .padding()
                            .foregroundColor(.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.white, lineWidth: 2)
                            )
                        let _ = print(disabledSubmit)
                    }.disabled(disableSubmit())
                        .background(disableSubmit() ? Color.gray : Color.red)
                    .cornerRadius(10)
                    .buttonStyle(BorderlessButtonStyle())
                    Spacer()
                    Button(action: {
                        shops = [Business]()
                        search = ""
                        distance = "10"
                        autodetect = false
                        location = ""
                        categoryIndex = 0
                        selectedCategory = "all"
                        observedSearch.loaded = false
                    }) {
                        Text("Clear")
                            .frame(minWidth: 0, maxWidth: 80)
                            .font(.system(size: 18))
                            .padding()
                            .foregroundColor(.white)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Color.white, lineWidth: 2)
                            )
                    }
                    .background(Color.blue) // If you have this
                    .cornerRadius(10)
                    .buttonStyle(BorderlessButtonStyle())
                }
                .padding(.horizontal)
                Section() {
                    Text("Results")
                        .font(.title)
                        .fontWeight(.bold)
                    if (observedSearch.loading && shops.count == 0) {
                        VStack {
                            ProgressView()
                                .frame(maxWidth: .infinity)
                                .padding(.bottom, -15.0)
                            Text("loading...")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                                .padding()
                        }
                        .padding(.top, 16.0)
                    } else if (observedSearch.loaded &&
                               shops.count == 0) {
                        Text("No results available.")
                            .foregroundColor(.red)
                    } else {
                        ForEach(Array(shops.enumerated()), id:\.element) { index, shop in
                            VStack(alignment: .leading) {
                                NavigationLink {
                                    BusinessView(shop: shop)
                                        .navigationBarTitleDisplayMode(.inline)
                                } label: {
                                    HStack {
                                        Text(String(index + 1))
                                            .frame(width: 22, alignment: .leading)
                                        if shop.imageURL != nil {
                                            AsyncImage(
                                                url: URL(string: shop.imageURL!),
                                                content: { image in
                                                    image.resizable()
                                                        .scaledToFill()
                                                        .frame(width: 50, height: 50, alignment: .center)
                                                        .clipped()
                                                },
                                                placeholder: {
                                                    ProgressView()
                                                }
                                            )
                                        } else {
                                            Text("img")
                                                .frame(minWidth: 50, minHeight: 50)
                                        }
                                        Text(shop.name)
                                            .frame(width: 125, alignment: .leading)
                                        Spacer()
                                        if let rating = shop.rating! {
                                            Text(String(rating))
                                        }
                                        Spacer()
                                        if let distance = shop.distance! {
                                            Text(String(Int(distance / 1609)))
                                        }
                                    }
                                }
                            }.padding(.horizontal, 8)
                                .navigationDestination(for: Business.self) { shop in
                                    BusinessView(shop: shop)
                                }
                        }
                    }
                    
                }
            }
            .navigationTitle("Business Search")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    NavigationLink(destination: ReservationsView()) {
                        Label("Bookings", systemImage: "calendar.badge.clock")
                            .foregroundColor(Color.blue)
                    }
                }
            }
        }.onAppear {
            print("uo", distance.count, search.count)
            
        }

    }
    
    func disableSubmit() -> Bool {
        return search.count == 0 ? true : distance.count == 0 ? true : autodetect ? false : location.count > 0 ? false : true
    }
    
    func addAutocompleteResults() {
        observed.getResults(search: search)
    }
}

struct PopoverContent: View {
    var body: some View {
        Text("This should be presented\nin a popover.")
            .font(.subheadline)
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(disabledSubmit: false)
    }
}
