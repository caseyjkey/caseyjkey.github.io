//
//  BusinessView.swift
//  yelp-shops
//
//  Created by Key, Casey on 11/27/22.
//

import Foundation
import SwiftUI
import Alamofire



struct BusinessView: View {
    var shop: Business
    
    @State var shopDetails: BusinessDetails?
    @State var loading = false

    
    var body: some View {
        VStack {
            if loading || shopDetails == nil {
                VStack {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, -15.0)
                    Text("loading...")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding()
                }
                .padding(.top, 16.0)
            } else {
                TabView {
                    DetailsView(shop: shopDetails!)
                        .tabItem {
                            Label("Business Detail", systemImage: "text.bubble.fill")
                        }
                    MapView(coordinates: shopDetails!.coordinates!, name: shopDetails!.name!)
                         .tabItem {
                             Label("Map Location", systemImage: "location.fill")
                         }
                    ReviewsView(id: shopDetails!.id!)
                         .tabItem {
                             Label("Reviews", systemImage: "message.fill")
                         }
                }
            }
        }
        .task {
            loading = true
            shopDetails = await Self.getDetails(id: shop.id) ?? nil // usually we have a try catch around this so we can show an error message
            debugPrint("shopDetails", shopDetails as Any, loading)
            loading = false
        }
    }
    
    static func getDetails(id: String) async -> BusinessDetails? {
        let params = [
            "id": id
        ]
        do {
            let result = try await AF.request("https://api-dot-next-yelp-shops.wl.r.appspot.com/details", parameters: params).serializingDecodable(BusinessDetails.self).value
            
            return result
        } catch {
            print("Error retrieving shop details:", error)
        }
        return nil
    }
}
