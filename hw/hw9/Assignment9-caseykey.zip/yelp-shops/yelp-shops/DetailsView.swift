//
//  DetailsView.swift
//  yelp-shops
//
//  Created by Key, Casey on 11/30/22.
//

import Foundation
import SwiftUI


struct DetailsView: View {
    @State var shop: BusinessDetails
    @State private var formOpen = false
    @State private var reserved = false
    @State var showToast: Bool = false

    
    init(shop: BusinessDetails) {
        @AppStorage("reservations") var reservations = try! JSONEncoder().encode([Reservation]())
        let decodedReservations = try! JSONDecoder().decode([Reservation].self, from: reservations)
        if decodedReservations.contains(where: {$0.name == shop.name}) {
            self.reserved = true
        }
        self.shop = shop
    }
    
    var body: some View {
        
        return VStack {
            Text(shop.name!)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding([.leading, .bottom, .trailing])
            let address = shop.location?.displayAddress!.joined(separator: " ")
            VStack {
                HStack {
                    VStack(alignment: .leading) {
                        Text("Address")
                            .fontWeight(.bold)
                        Text(address!)
                    }
                    Spacer()
                    VStack(alignment: .trailing) {
                        Text("Category")
                            .fontWeight(.bold)
                        let category = shop.categories!.map { $0.title! }
                        Text(category.joined(separator: " | "))
                    }
                }
                .padding(.bottom)
                HStack {
                    VStack(alignment: .leading) {
                        Text("Phone")
                            .fontWeight(.bold)
                        Text(shop.displayPhone ?? "")
                    }
                    Spacer()
                    VStack(alignment: .trailing) {
                        Text("Price Range")
                            .fontWeight(.bold)
                        Text(shop.price ?? "")
                    }
                }
                .padding(.bottom)
                HStack {
                    VStack(alignment: .leading) {
                        Text("Status")
                            .fontWeight(.bold)
                        if let openNow = shop.hours?[0].isOpenNow {
                            if openNow {
                                Text("Open Now")
                                    .foregroundColor(Color.green)
                            } else {
                                Text("Closed")
                                    .foregroundColor(Color.red)
                            }
                        }
                    }
                    Spacer()
                    VStack(alignment: .trailing) {
                        Text("Visit Yelp for more")
                            .fontWeight(.bold)
                        Text(.init("[Business Link](\(shop.url!))"))
                    }
                    
                }
                .padding(.bottom)
            }.padding(.horizontal)
            Button(action: {
                if !reserved {
                    formOpen.toggle()
                } else {
                    @AppStorage("reservations") var reservations = try! JSONEncoder().encode([Reservation]())
                    var decodedReservations = try! JSONDecoder().decode([Reservation].self, from: reservations)
                    if decodedReservations.count > 0 {
                        if let index = decodedReservations.firstIndex(where: { $0.name == shop.name }) {
                            decodedReservations.remove(at: index)
                        }
                        if let encoded = try? JSONEncoder().encode(decodedReservations) {
                            reservations = encoded
                            reserved = false
                            withAnimation {
                                self.showToast.toggle()
                            }
                        }
                    }
                }
            }) {
                Text(reserved ? "Cancel Reservation" : "Reserve Now")
                    //.frame(minWidth: 0, maxWidth: 80)
                    .font(.system(size: 18))
                    .padding()
                    .foregroundColor(.white)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(Color.white, lineWidth: 2)
                    )
            }
            .sheet(isPresented: $formOpen) {
                FormView(reserved: $reserved, name: shop.name!)
            }
            .background(reserved ? Color.blue : Color.red) // If you have this
            .cornerRadius(10)
            .buttonStyle(BorderlessButtonStyle())
            HStack {
                Text("Share on:")
                Button(action: {
                    var components = URLComponents()
                    components.scheme = "https"
                    components.host = "facebook.com"
                    components.path = "/sharer/sharer.php"
                    components.queryItems = [
                        URLQueryItem(name: "u", value:  String(shop.url!.split(separator: "?")[0]))
                    ]
                    print(components.string!)
                    guard let fb = URL(string: components.string!), UIApplication.shared.canOpenURL(fb) else {
                        return
                    }
                    UIApplication.shared.open(fb, options: [:], completionHandler: nil)
                }) {
                    Image("fb")
                        .resizable()
                        .frame(width: 40, height: 40)
                }
                Button(action: {
                    let text = "Check out \(shop.name!) on Yelp."
                    var components = URLComponents()
                    components.scheme = "https"
                    components.host = "twitter.com"
                    components.path = "/intent/tweet"
                    components.queryItems = [
                        URLQueryItem(name: "text", value: text),
                        URLQueryItem(name: "url", value: String(shop.url!.split(separator: "?")[0]))
                    ]
                    print(components.string!)
                    guard let twitter = URL(string: components.string!), UIApplication.shared.canOpenURL(twitter) else {
                        return
                    }
                    UIApplication.shared.open(twitter, options: [:], completionHandler: nil)
                }) {
                    Image("twitter")
                        .resizable()
                        .frame(width: 40, height: 40)
                }
            }
            TabView {
                ForEach(shop.photos?.prefix(3) ?? [], id:\.self) { url in
                    AsyncImage(
                        url: URL(string: url),
                        content: { image in
                            image.resizable()
                                .scaledToFill()
                                .frame(height: 300, alignment: .center)
                                .clipped()
                                .padding(.horizontal, 50)
                        },
                        placeholder: {
                            ProgressView()
                        }
                    ).tabItem {
                        Image(systemName: "circle")
                            .renderingMode(.original)
                            .resizable(resizingMode: .stretch)
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 1.0, height: 1.0)
                            .font(.system(size: 100))
                    }

                }
            }.onAppear() {
                //let appearance = UITabBarAppearance()

                //appearance.stackedItemPositioning = .centered
                //appearance.stackedItemWidth = 10

                //UITabBar.appearance().standardAppearance = appearance
            }
        }
        .toast(isShowing: $showToast, text: Text("Reservation cancelled!"))
    }
}


