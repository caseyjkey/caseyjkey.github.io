//
//  Geocoding.swift
//  yelp-shops
//
//  Created by Key, Casey on 11/23/22.
//

import Foundation
import MapKit

class Geocoding {
    
    var coordinates: CLLocationCoordinate2D
    var name: String?
    var address: String?
    var formattedAddress: String?
    var boundNorthEast: CLLocationCoordinate2D?
    var boundSouthWest: CLLocationCoordinate2D?
    
    init(coordinates: CLLocationCoordinate2D) {
        self.coordinates = coordinates
    }
    
}
