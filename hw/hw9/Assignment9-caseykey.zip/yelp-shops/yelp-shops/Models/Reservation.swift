//
//  Reservation.swift
//  yelp-shops
//
//  Created by Key, Casey on 12/4/22.
//

import Foundation

struct Reservation: Codable, Hashable {
    var name: String
    var hours: String
    var minutes: String
    var email: String
    var date: Date
}
