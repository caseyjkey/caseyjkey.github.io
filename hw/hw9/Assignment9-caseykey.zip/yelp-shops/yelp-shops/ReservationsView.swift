//
//  ReservationsView.swift
//  yelp-shops
//
//  Created by Key, Casey on 12/4/22.
//

import SwiftUI



struct ReservationsView: View {
    
    @State private var decodedReservations: [Reservation]
    let formatter = DateFormatter();
    
    init() {
        @AppStorage("reservations") var initReservations = try! JSONEncoder().encode([Reservation]())
        decodedReservations = try! JSONDecoder().decode([Reservation].self, from: initReservations)
        formatter.dateFormat = "Y-M-d";
    }
    
    

    var body: some View {
        return VStack {
            if decodedReservations.count > 0 {
                List() {
                    ForEach(decodedReservations, id:\.self) { reservation in
                        HStack {
                            Text(reservation.name)
                            Text(formatter.string(from: reservation.date))
                            Text("\(reservation.hours):\(reservation.minutes)")
                            Text(reservation.email)
                        }
                    }.onDelete(perform: delete)
                }
            } else {
                Text("There are no reservations.")
            }
        }
        .navigationTitle("Reservations")
        .onAppear {
            @AppStorage("reservations") var reservations = try! JSONEncoder().encode([Reservation]())
            decodedReservations = try! JSONDecoder().decode([Reservation].self, from: reservations)
        }
    }
    
    func delete(at offsets: IndexSet) {
        @AppStorage("reservations") var reservations = try! JSONEncoder().encode([Reservation]())
        decodedReservations.remove(atOffsets: offsets)
        if let encoded = try? JSONEncoder().encode(decodedReservations) {
            reservations = encoded
        }
    }
}

struct ReservationsView_Previews: PreviewProvider {
    static var previews: some View {
        ReservationsView()
    }
}
