//
//  yelp_shops2App.swift
//  yelp-shops2
//
//  Created by Key, Casey on 11/17/22.
//

import SwiftUI

@main
struct yelp_shopsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
