//
//  MapView.swift
//  yelp-shops
//
//  Created by Key, Casey on 12/6/22.
//

import SwiftUI
import CoreLocation
import MapKit


struct MapLocation: Identifiable {
    let id = UUID()
    let name: String
    let latitude: Double
    let longitude: Double
    var coordinate: CLLocationCoordinate2D {
        CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
}

struct MapView: View {
    var coords: Coordinates
    @State private var region: MKCoordinateRegion
    private var annotation: [MapLocation]
    
    init(coordinates: Coordinates, name: String) {
        coords = coordinates
        _region = State(initialValue: MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: coords.latitude!, longitude: coords.longitude!), span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)))
        annotation = [MapLocation(name: name, latitude: coords.latitude!, longitude: coords.longitude!)]
    }

    var body: some View {
        Map(coordinateRegion: $region, annotationItems: annotation, annotationContent: { location in
            MapAnnotation(
                coordinate: location.coordinate,
                content: {
                    Image(systemName: "pin.circle.fill").foregroundColor(.red)
                    Text(location.name).font(.system(size: 7)).foregroundColor(.red)
                }
            )
        })
            .frame(
                maxWidth: .infinity,
                maxHeight: .infinity
            )
    }
}
