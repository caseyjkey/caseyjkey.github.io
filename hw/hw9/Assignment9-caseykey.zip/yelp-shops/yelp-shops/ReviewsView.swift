//
//  ReviewsView.swift
//  yelp-shops
//
//  Created by Key, Casey on 12/6/22.
//

import SwiftUI
import Alamofire

struct ReviewsView: View {
    @State var id: String
    @State var loading = false
    @State var reviews: Reviews?
    
    init(id: String) {
        self.id = id
        self.reviews = reviews
    }
    
    var body: some View {
        return VStack {
            if !loading && reviews?.total ?? 0 > 0 {
                List() {
                    ForEach(reviews!.reviews!, id:\.self) { review in
                        VStack {
                            HStack {
                                Text(review.user!.name!)
                                    .fontWeight(.bold)
                                Spacer()
                                Text("\(review.rating!)/5")
                                    .fontWeight(.bold)
                            }
                            Text(review.text!)
                                .foregroundColor(.gray)
                                .multilineTextAlignment(.leading)
                                .padding(.vertical, 10.0)
                            Text(review.timeCreated!.components(separatedBy: " ")[0])
                                .multilineTextAlignment(.center)
                        }
                    }
                }
            } else if loading {
                VStack {
                    ProgressView()
                        .frame(maxWidth: .infinity)
                        .padding(.bottom, -15.0)
                    Text("loading...")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                        .padding()
                }
                .padding(.top, 16.0)
            }
            else {
                Text("There are no reviews.")
            }
        }
        .task {
            loading = true
            reviews = await Self.getReviews(id: id) ?? nil // usually we have a try catch around this so we can show an error message
            loading = false
        }
    }
    
    static func getReviews(id: String) async -> Reviews? {
        let params = [
            "id": id
        ]
        do {
            let result = try await AF.request("https://api-dot-next-yelp-shops.wl.r.appspot.com/reviews", parameters: params).serializingDecodable(Reviews.self).value
            
            return result
        } catch {
            print("Error retrieving shop details:", error)
        }
        return nil
    }
}

