//
//  FormView.swift
//  yelp-shops
//
//  Created by Key, Casey on 12/4/22.
//

import SwiftUI
import Combine

class ViewModel: ObservableObject {
    @Published var email = ""
    @Published var valid = false
}


// Credit to: https://stackoverflow.com/questions/71509097/creating-an-email-input-field-in-swiftui
struct EmailInputView: View {
    var placeHolder: String = ""
    @Binding var txt: String
    
    var body: some View {
        TextField(placeHolder, text: $txt)
            .keyboardType(.emailAddress)
            .onReceive(Just(txt)) { newValue in
                let validString = newValue.filter { "1234567890abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ._-+$!~&=#[]@".contains($0) }
                if validString != newValue {
                    self.txt = validString
                }
        }
    }
    
    

}

struct FormView: View {
    @Binding var reserved: Bool
    @State var name: String
    @State private var date = Date.now
    @State private var hour = "10"
    @State private var minute = "00"
    @StateObject var viewModel = ViewModel()
    @State private var showToast: Bool = false
    @State private var showSuccess: Bool = false
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        List {
            Section() {
                Text("Reservation Form")
                    .font(.title)
                    .fontWeight(.bold)
                    .frame(width: 500)
                    .multilineTextAlignment(.center)
            }
            Section {
                GeometryReader { geo in
                    Text("\(name)")
                        .fixedSize(horizontal: false, vertical: true)
                        .lineLimit(nil)
                        .frame(width: geo.size.width, height: .infinity)
                        .font(.system(size: 26))
                        .fontWeight(.bold)
                }
            }
            Section {
                VStack {
                    HStack {
                        Text("Email:")
                            .foregroundColor(.gray)
                        EmailInputView(placeHolder: "", txt: $viewModel.email)
                    }
                    Divider()
                    HStack {
                        Text("Date/Time:")
                            .foregroundColor(.gray)
                        DatePicker("", selection: $date, in: Date.now..., displayedComponents: .date)
                        HStack {
                            Menu(hour) {
                                Toggle("10", isOn: hourBinding("10"))
                                Toggle("11", isOn: hourBinding("11"))
                                Toggle("12", isOn: hourBinding("12"))
                                Toggle("13", isOn: hourBinding("13"))
                                Toggle("14", isOn: hourBinding("14"))
                                Toggle("15", isOn: hourBinding("15"))
                                Toggle("16", isOn: hourBinding("16"))
                                Toggle("17", isOn: hourBinding("17"))
                            }.padding(.trailing, 5.0).foregroundColor(.black)
                            Text(":")
                            Menu(minute) {
                                Toggle("00", isOn: minuteBinding("00"))
                                Toggle("15", isOn: minuteBinding("15"))
                                Toggle("30", isOn: minuteBinding("30"))
                                Toggle("45", isOn: minuteBinding("45"))
                            }.padding(.leading, 8.0).foregroundColor(.black)
                        }
                        .padding(7)
                        .background(Color(UIColor.lightGray).opacity(0.2))
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                    .padding(.vertical, 10.0)
                    Divider()
                    VStack {
                        Button(action: {
                            checkEmail(changedEmail: viewModel.email)
                            if viewModel.valid {
                                print("submit reserve", viewModel.email)
                                @AppStorage("reservations") var reservations = try! JSONEncoder().encode([Reservation]())
                                let reservation = Reservation(name: name, hours: hour, minutes: minute, email: viewModel.email, date: date)
                                var decodedReservations = try! JSONDecoder().decode([Reservation].self, from: reservations)
                                decodedReservations.append(reservation)
                                if let encoded = try? JSONEncoder().encode(decodedReservations) {
                                    reservations = encoded
                                }
                                reserved = true
                                showSuccess.toggle()
                            } else {
                                withAnimation {
                                    showToast.toggle()
                                }
                            }
                        }) {
                            Text("Submit")
                                .font(.system(size: 18))
                                .padding(.horizontal, 30.0)
                                .padding(.vertical)
                                .foregroundColor(.white)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(Color.white, lineWidth: 2)
                                )
                        }
                        .background(Color.blue)
                        .cornerRadius(15)
                        .buttonStyle(BorderlessButtonStyle())
                    }
                    .padding(.vertical, 10.0)
                    
                }
                
            }
            
        }
        .toast(isShowing: $showToast, text: Text("Please enter a valid email."))
        .sheet(isPresented: $showSuccess, onDismiss: { dismiss() }) {
            SuccessView(name: name)
        }
    }
    
    private func checkEmail(changedEmail: String) {
        print("-----> onEmailInputChanged: \(changedEmail) ")
        if emailValidator(email: changedEmail) == true {
            print("validated")
            viewModel.valid = true
        } else {
            print("invalidated email")
            viewModel.valid = false
            viewModel.email = ""
        }
    }
    
    private func emailValidator(email: String) -> Bool {
        if email.count > 100 {
                return false
            }
            let emailFormat = "(?:[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}~-]+(?:\\.[\\p{L}0-9!#$%\\&'*+/=?\\^_`{|}" + "~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\" + "x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[\\p{L}0-9](?:[a-" + "z0-9-]*[\\p{L}0-9])?\\.)+[\\p{L}0-9](?:[\\p{L}0-9-]*[\\p{L}0-9])?|\\[(?:(?:25[0-5" + "]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-" + "9][0-9]?|[\\p{L}0-9-]*[\\p{L}0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21" + "-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])"
            //let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
            let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
            return emailPredicate.evaluate(with: email)
    }
    
    private func hourBinding(_ option: String) -> Binding<Bool> {
        Binding<Bool>(get: { hour == option }, set: { if $0 { hour = option } })
    }
    
    private func minuteBinding(_ option: String) -> Binding<Bool> {
        Binding<Bool>(get: { minute == option }, set: { if $0 { minute = option } })
    }
}

struct SuccessView: View {
    @Environment(\.dismiss) var dismiss
    var name: String
    
    var body: some View {
        VStack {
            Group {
                VStack {
                    Text("Congratulations!")
                        .padding(.bottom)
                        .foregroundColor(.white)
                    Text("You have successfully made a reservation at \(name)")
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 10.0)
                }
                
                Button(action: {
                    dismiss()
                }) {
                    Text("Done")
                        .frame(width: 175, height: 25)
                        .font(.system(size: 18))
                        .padding()
                        .foregroundColor(.green)
                        .overlay(
                            RoundedRectangle(cornerRadius: 30)
                                .stroke(Color.white, lineWidth: 2)
                        )
                }
                .background(Color.white)
                .cornerRadius(30)
                .buttonStyle(BorderlessButtonStyle())
            }.frame(maxHeight: .infinity, alignment: .bottom)
        }
        .frame(
            maxWidth: .infinity,
            maxHeight: .infinity
        )
        .background(Color.green)
        .task(dismissDelay)
    }
    
    func dismissDelay() async {
        try? await Task.sleep(nanoseconds: 2_000_000_000)
        dismiss()
    }
}

struct FormView_Previews: PreviewProvider {
    static var previews: some View {
        FormView(reserved: .constant(false), name: "Donut Shop With a Much Longer Name")
    }
}
